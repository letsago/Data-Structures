#pragma once

#include "myvector_class.h"

bool pigLatinTranslate(const MyVector<char>& input, MyVector<char>& output);
// bool appropriatelySpace(const MyVector<char>& input, MyVector<char>& output);
bool doInvalidCharsExist(const MyVector<char>& input);

